<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HealthMate</title>
</head>
<body>
     <footer>
        <div class="socials">
            <img src="pictures/instagram.png" alt="Instagram">
            <img src="pictures/twitter.png" alt="Twitter">
            <img src="pictures/facebook.png" alt="Facebook">
            <img src="pictures/youtube.png" alt="Youtube">           
        </div>

        <h5>Terms & Conditions         Privacy Policies</h5>
    </footer>
</body>
</html>